public class HouseBlend extends Bebida {
	public HouseBlend() {
		descripcion = "Cafe House Blend";
		}
	
	public double costo() {
		return 45;
		}
}