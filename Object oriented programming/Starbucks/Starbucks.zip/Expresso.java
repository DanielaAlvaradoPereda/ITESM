public class Expresso extends Bebida {
	
	public Expresso() {
		descripcion = "Expresso";
		}
	
	public double costo() {
		return 40;
		}
}