public class DarkRoast extends Bebida {
	public DarkRoast() {
		descripcion = "Dark Roast";
		}
	
	public double costo() {
		return 60;
		}
}