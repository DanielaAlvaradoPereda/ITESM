public abstract class DecoradorCondimento extends Bebida
{
	public abstract String getDescripcion();
}