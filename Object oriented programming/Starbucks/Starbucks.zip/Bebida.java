public abstract class Bebida implements Costos
{	
	String descripcion = "Bebida desconocida";
	
	public String getDescripcion()
	{
		return descripcion;
	}
//	public abstract double costo();
}