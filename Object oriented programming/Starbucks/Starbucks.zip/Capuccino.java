public class Capuccino extends Bebida
{
	public Capuccino()
	{
		descripcion = "Capuccino";
	}
	
	public double costo()
	{
		return 49;
	}
}