public class Frappuccino extends Bebida
{
	public Frappuccino()
	{
		descripcion = "Frappuccino";
	}
	
	public double costo()
	{
		return 55;
	}
}