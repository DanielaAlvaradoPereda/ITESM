public interface Costos
{
	public double costo();
}