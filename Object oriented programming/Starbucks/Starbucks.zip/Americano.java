public class Americano extends Bebida
{
	public Americano()
	{
		descripcion = "Americano";
	}
	
	public double costo()
	{
		return 40;
	}
}