/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package genericos;

/**
 *
 * @author david
 */
public class Ordena {


   public static void main(String args[]) {
       
       int i;
      
      System.out.println("El maximo de 3, 4, 5 es " + maximo( 3, 4, 5 ));

      System.out.println("El maximo de 6.6, 8.8, 7.7 es " + maximo( 6.6, 8.8, 7.7 ));

      System.out.println("El maximo de pera, manzana, naranja es " + maximo("pera", "manzana", "naranja"));
   
      System.out.println("Prueba de ordenamiento generica");
      
      
      Integer[] intArreglo = { 6, 5, 3, 2, 7, 1, 4 };
      Integer[] ordenadoI = new Integer[7];
      ordenadoI = ordenaInsercion(intArreglo, ordenadoI, 7);
      
      imprimeArreglo(ordenadoI);
      
      Double[] dobArreglo = { 6.3, 5.2, 3.1, 2.9, 7.4, 1.0, 4.54 };
      Double[] ordenadoD = new Double[7];
      ordenadoD = ordenaInsercion(dobArreglo, ordenadoD, 7);
      
      imprimeArreglo(ordenadoD);

      String[] strArreglo = { "hola", "quetal", "buenos", "dias", "hoy", "es", "lunes" };
      String[] ordenadoS = new String[7];
      ordenadoS = ordenaInsercion(strArreglo, ordenadoS, 7);
      
      imprimeArreglo(ordenadoS);


   }
 
   
   public static <T extends Comparable<T>> T maximo(T x, T y, T z) {
      T max = x;   
      
      if(y.compareTo(max) > 0) {
         max = y;   
      }
      
      if(z.compareTo(max) > 0) {
         max = z;                
      }
      return max;   
   }
   
   public static <E extends Comparable<E>> E[] ordenaInsercion(E [] elementos, E [] orden, int n) {
   
       E max, min;
       int i, j, pos_min;
       
       
       max = encuentraMax(elementos, n);
       
       i = 0;
       pos_min = 0;
       
       while (i < n ) {
           
           j = 0;
           min = elementos[0];
           pos_min = 0;
           
          for(E elem: elementos) {
               
               if (elem.compareTo(min) < 0){
                    min = elem;
                    pos_min = j;
               }
                  
               j++;
               
           }
            
           orden[i] = min;
           elementos[pos_min] = max;
	   i++;
       }
       
       return orden;
   
   }
   
   public static <E extends Comparable<E>> E encuentraMax(E [] elementos, int n) {
       
       E max;
       int i;
       max = elementos[0];
       
       for (i = 0 ; i < n ; i++) {
           if (elementos[i].compareTo(max) > 0)
               max = elementos[i];
       }
       
       return max;
       
   }
   
   public static <E extends Comparable<E>> void imprimeArreglo( E[] arreglo ) {

      for(E elemento : arreglo) {

         System.out.print(elemento + " ");

      }
      
      System.out.println(" ");
      
   }
   
   
}